# Mirza Monir — Portfolio Website

A 5-page static site: Home, About, Experience, Education, Contact.

## Files
- `index.html`, `about.html`, `experience.html`, `education.html`, `contact.html`
- `style.css` — shared stylesheet
- `assets/photo.jpg` — profile photo

## Publish on GitHub Pages
1. Create a new GitHub repository (e.g. `mirza-monir-portfolio`).
2. Upload all files in this folder, keeping `assets/photo.jpg` inside an `assets` folder.
3. Go to **Settings → Pages** in the repo.
4. Under **Source**, choose the `main` branch and `/ (root)` folder, then **Save**.
5. Your site will be live at `https://<your-username>.github.io/<repo-name>/` within a few minutes.

No build step is needed — it's plain HTML/CSS.
